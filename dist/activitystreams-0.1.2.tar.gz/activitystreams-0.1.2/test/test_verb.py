from activitystreams.models.verb import Verb
from activitystreams.exception import ActivityException

import unittest


class VerbTest(unittest.TestCase):
    def test_valid_verb(self):
        verb = Verb('send')
        self.assertEqual(verb.verb, 'send')

    def test_verb_required(self):
        self.assertRaises(ActivityException, Verb, '')

    def test_verb_needs_to_be_str(self):
        self.assertRaises(ActivityException, Verb, 42)

    def test_verb_cannot_be_none(self):
        self.assertRaises(ActivityException, Verb, None)
