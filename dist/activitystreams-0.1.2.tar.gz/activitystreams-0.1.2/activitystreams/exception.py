class ActivityException(Exception):
    pass
